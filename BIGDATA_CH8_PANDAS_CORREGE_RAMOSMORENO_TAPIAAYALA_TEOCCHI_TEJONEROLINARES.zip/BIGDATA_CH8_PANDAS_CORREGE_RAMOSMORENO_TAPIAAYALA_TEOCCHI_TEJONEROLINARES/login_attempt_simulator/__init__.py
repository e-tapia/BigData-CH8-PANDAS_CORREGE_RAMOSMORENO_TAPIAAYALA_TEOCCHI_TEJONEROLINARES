"""Package for simulating login data."""

from .login_attempt_simulator import LoginAttemptSimulator
