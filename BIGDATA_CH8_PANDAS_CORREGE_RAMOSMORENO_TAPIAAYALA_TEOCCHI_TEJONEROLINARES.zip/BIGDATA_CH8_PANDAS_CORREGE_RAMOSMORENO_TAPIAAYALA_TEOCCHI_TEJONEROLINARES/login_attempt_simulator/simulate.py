def make_user_base(out_file):
with open(out_file, 'w') as user_base:
for first, last in itertools.product(
string.ascii_lowercase,
['smith', 'jones', 'kim', 'lopez', 'brown']
)
user_base.write(first + last + '\n')

for account in ['admin', 'master', 'dba']:
user_base.write(account + '\n')

     
